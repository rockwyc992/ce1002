package ce1002.a6.s102502044;

public class A6 {

    //宣告陣列，輸出所有的hero
    public A6() {
        MyFrame frame = new MyFrame();
    }
    
    public static void main (String[] argv) {
        new A6();
    }
}
