package ce1002.e4.s102502044;

public class E4 {

    E4() {
        Dog dog = new Dog();
        Cat cat = new Cat();
        dog.status();
        cat.status();
    }

    public static void main(String[] argv) {
        new E4();
    }
}
