package ce1002.e1.s102502044;

public class E1 {

    public E1() {
		System.out.println("hello world");
    }

	public static void main(String[] args) {
        new E1();
	}

}
